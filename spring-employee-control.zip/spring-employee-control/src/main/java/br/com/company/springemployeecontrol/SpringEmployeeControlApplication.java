package br.com.company.springemployeecontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEmployeeControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEmployeeControlApplication.class, args);
	}

}
