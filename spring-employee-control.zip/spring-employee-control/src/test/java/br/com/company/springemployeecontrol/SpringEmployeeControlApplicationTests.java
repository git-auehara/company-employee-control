package br.com.company.springemployeecontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmployeeControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
